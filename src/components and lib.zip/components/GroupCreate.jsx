import { useMemo, useState } from 'react'
import { colors, cv } from '../styles/theme'

const ICONS = ['📔', '✉️', '📜', '🗂️', '🌸', '🌊', '🔥', '🌿', '🌙', '✨', '🎭', '🎨']
const GROUP_COLORS = ['#c97b5a', '#7a8ec9', '#7ab89a', '#b97ab8', '#c9a87a', '#7ac9c9']
const LAYOUTS = [
  { id: 'diary', icon: '📔', label: 'Diary', desc: 'Entries, dates, moods, and shared memories' },
  { id: 'letter', icon: '✉️', label: 'Letter', desc: 'A softer format for notes and long messages' },
  { id: 'script', icon: '📜', label: 'Script', desc: 'Scenes, dialogue, and story sessions' },
  { id: 'project', icon: '🗂️', label: 'Project', desc: 'Task-like writing with a tidy board feel' },
]
const palette = ['#c97b5a', '#7a8ec9', '#7ab89a', '#b97ab8', '#c9a87a', '#7ac9c9']
const colorFor = (id = '') => palette[(id.charCodeAt(0) || 0) % palette.length]
const displayName = (p) => p?.display_name || p?.name || p?.username || 'Friend'
const initials = (name = '') => name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '?'

export default function GroupCreate({ friends = [], onClose, onCreate }) {
  const [name, setName] = useState('')
  const [icon, setIcon] = useState('📔')
  const [groupColor, setGroupColor] = useState('#c97b5a')
  const [layout, setLayout] = useState('diary')
  const [invites, setInvites] = useState([])
  const [tab, setTab] = useState('invite')

  const selectedLayout = useMemo(() => LAYOUTS.find(l => l.id === layout) || LAYOUTS[0], [layout])
  const diaryName = name.trim() || 'Untitled Diary'
  const canCreate = Boolean(name.trim())

  const toggleInvite = (id) => setInvites(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id])

  const handleCreate = () => {
    if (!canCreate) return
    onCreate({ name: name.trim(), icon, color: groupColor, layout, members: invites })
  }

  return (
    <>
      <style>{`
        .vn-modal-scroll::-webkit-scrollbar { width: 5px; }
        .vn-modal-scroll::-webkit-scrollbar-track { background: transparent; }
        .vn-modal-scroll::-webkit-scrollbar-thumb { background: var(--vn-border); border-radius: 999px; }
        .vn-create-input:focus { border-color: ${groupColor}; box-shadow: 0 0 0 3px ${groupColor}22; }
      `}</style>

      <div style={ss.overlay} onClick={e => e.target === e.currentTarget && onClose()}>
        <div style={ss.modal}>
          <div style={{ ...ss.preview, background: `linear-gradient(135deg, ${groupColor}3a, rgba(255,255,255,0.03))` }}>
            <div style={{ ...ss.previewIcon, background: `${groupColor}2e`, borderColor: `${groupColor}70` }}>{icon}</div>
            <div style={{ minWidth: 0 }}>
              <div style={ss.previewTitle}>{diaryName}</div>
              <div style={ss.previewSub}>{selectedLayout.label} space</div>
            </div>
            <button style={ss.closeBtn} onClick={onClose} title="Close">×</button>
          </div>

          <div style={ss.body} className="vn-modal-scroll">
            <section style={ss.section}>
              <div style={ss.sectionHead}>
                <label style={ss.label}>Diary Name</label>
                <span style={ss.hint}>{name.length}/40</span>
              </div>
              <input
                className="vn-create-input"
                style={ss.input}
                placeholder="Summer Vacation 2026"
                value={name}
                maxLength={40}
                onChange={e => setName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleCreate()}
                autoFocus
              />
            </section>

            <section style={ss.section}>
              <label style={ss.label}>Icon</label>
              <div style={ss.iconGrid}>
                {ICONS.map(ic => (
                  <button
                    key={ic}
                    style={{
                      ...ss.iconOption,
                      background: icon === ic ? `${groupColor}24` : cv.elevated,
                      borderColor: icon === ic ? groupColor : cv.border,
                    }}
                    onClick={() => setIcon(ic)}
                    title={ic}
                  >
                    {ic}
                  </button>
                ))}
              </div>
            </section>

            <section style={ss.section}>
              <label style={ss.label}>Accent Color</label>
              <div style={ss.swatches}>
                {GROUP_COLORS.map(c => (
                  <button
                    key={c}
                    style={{
                      ...ss.swatch,
                      background: c,
                      outline: groupColor === c ? `2px solid ${colors.text}` : '2px solid transparent',
                      transform: groupColor === c ? 'scale(1.08)' : 'scale(1)',
                    }}
                    onClick={() => setGroupColor(c)}
                    title={c}
                  />
                ))}
              </div>
            </section>

            <section style={ss.section}>
              <label style={ss.label}>Layout</label>
              <div style={ss.layoutGrid}>
                {LAYOUTS.map(l => (
                  <button
                    key={l.id}
                    style={{
                      ...ss.layoutOption,
                      background: layout === l.id ? `${groupColor}18` : cv.elevated,
                      borderColor: layout === l.id ? groupColor : cv.border,
                    }}
                    onClick={() => setLayout(l.id)}
                  >
                    <span style={ss.layoutIcon}>{l.icon}</span>
                    <span style={ss.layoutText}>
                      <span style={ss.layoutLabel}>{l.label}</span>
                      <span style={ss.layoutDesc}>{l.desc}</span>
                    </span>
                  </button>
                ))}
              </div>
            </section>

            <section style={ss.section}>
              <div style={ss.sectionHead}>
                <label style={ss.label}>Invite</label>
                <span style={ss.hint}>{invites.length ? `${invites.length} selected` : 'Optional'}</span>
              </div>
              <div style={ss.tabs}>
                <button style={{ ...ss.tab, ...(tab === 'invite' ? ss.tabActive : {}) }} onClick={() => setTab('invite')}>Friends</button>
                <button style={{ ...ss.tab, ...(tab === 'link' ? ss.tabActive : {}) }} onClick={() => setTab('link')}>Invite Link</button>
              </div>

              {tab === 'invite' && (
                <div style={ss.friendList}>
                  {friends.length === 0 && (
                    <div style={ss.emptyFriends}>
                      Add friends in Direct Messages first, then they will show up here.
                    </div>
                  )}
                  {friends.map(friend => {
                    const selected = invites.includes(friend.id)
                    const name = displayName(friend)
                    const color = colorFor(friend.id)
                    return (
                      <button
                        key={friend.id}
                        style={{
                          ...ss.friendRow,
                          background: selected ? `${color}18` : cv.elevated,
                          borderColor: selected ? `${color}66` : cv.border,
                        }}
                        onClick={() => toggleInvite(friend.id)}
                      >
                        <span style={{ ...ss.friendAvatar, background: `${color}30`, color }}>
                          {friend.avatar_url
                            ? <img src={friend.avatar_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '50%' }} />
                            : initials(name)}
                        </span>
                        <span style={ss.friendName}>{name}</span>
                        <span style={{ ...ss.check, background: selected ? color : 'transparent', borderColor: selected ? color : cv.border }}>
                          {selected ? '✓' : ''}
                        </span>
                      </button>
                    )
                  })}
                </div>
              )}

              {tab === 'link' && (
                <div style={ss.linkNotice}>
                  Create the diary first, then open its chat settings to copy a real join link. The link needs the diary id, so it cannot exist until the diary is created.
                </div>
              )}
            </section>
          </div>

          <div style={ss.footer}>
            <button style={ss.btnCancel} onClick={onClose}>Cancel</button>
            <button
              style={{ ...ss.btnCreate, background: groupColor, opacity: canCreate ? 1 : 0.45, cursor: canCreate ? 'pointer' : 'not-allowed' }}
              onClick={handleCreate}
              disabled={!canCreate}
            >
              Create Diary
            </button>
          </div>
        </div>
      </div>
    </>
  )
}

const ss = {
  overlay: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 24 },
  modal: { width: 520, maxWidth: 'min(520px, calc(100vw - 32px))', maxHeight: 'min(720px, calc(100vh - 48px))', background: cv.surface, border: `1px solid ${cv.border}`, borderRadius: 18, display: 'flex', flexDirection: 'column', boxShadow: '0 32px 90px rgba(0,0,0,0.62)', overflow: 'hidden' },
  preview: { padding: '20px 22px', borderBottom: `1px solid ${cv.border}`, display: 'flex', alignItems: 'center', gap: 14, flexShrink: 0 },
  previewIcon: { width: 48, height: 48, borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, border: '1px solid transparent', flexShrink: 0 },
  previewTitle: { fontSize: 18, fontWeight: 700, color: cv.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  previewSub: { fontSize: 12, color: cv.textDim, marginTop: 3 },
  closeBtn: { marginLeft: 'auto', width: 32, height: 32, borderRadius: 8, border: `1px solid ${cv.border}`, background: cv.elevated, color: cv.textMid, cursor: 'pointer', fontSize: 18, lineHeight: 1, flexShrink: 0 },
  body: { flex: 1, overflowY: 'auto', padding: '18px 22px 20px', display: 'flex', flexDirection: 'column', gap: 20 },
  footer: { padding: '16px 22px', borderTop: `1px solid ${cv.border}`, display: 'flex', gap: 10, justifyContent: 'flex-end', flexShrink: 0 },
  section: { display: 'flex', flexDirection: 'column', gap: 10 },
  sectionHead: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  label: { fontSize: 11, color: cv.textDim, letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 700 },
  hint: { fontSize: 11, color: cv.textDim },
  input: { width: '100%', background: cv.elevated, border: `1px solid ${cv.border}`, borderRadius: 10, padding: '11px 13px', fontSize: 14, color: cv.text, outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box', userSelect: 'text', transition: 'border 0.15s, box-shadow 0.15s' },
  iconGrid: { display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 },
  iconOption: { height: 42, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 19, cursor: 'pointer', border: '1px solid transparent', transition: 'all 0.15s', fontFamily: 'inherit' },
  swatches: { display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' },
  swatch: { width: 28, height: 28, borderRadius: '50%', border: '2px solid rgba(0,0,0,0.25)', cursor: 'pointer', transition: 'transform 0.15s, outline 0.15s', outlineOffset: 2 },
  layoutGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 },
  layoutOption: { minHeight: 82, padding: 12, borderRadius: 12, border: '1px solid transparent', cursor: 'pointer', display: 'flex', gap: 10, textAlign: 'left', fontFamily: 'inherit', transition: 'all 0.15s' },
  layoutIcon: { fontSize: 20, flexShrink: 0 },
  layoutText: { display: 'flex', flexDirection: 'column', gap: 3, minWidth: 0 },
  layoutLabel: { fontSize: 13, fontWeight: 700, color: cv.text },
  layoutDesc: { fontSize: 11, color: cv.textDim, lineHeight: 1.35 },
  tabs: { display: 'grid', gridTemplateColumns: '1fr 1fr', background: cv.elevated, border: `1px solid ${cv.border}`, borderRadius: 10, padding: 4, gap: 4 },
  tab: { padding: '8px 10px', borderRadius: 8, border: 'none', background: 'transparent', color: cv.textDim, cursor: 'pointer', fontSize: 12, fontWeight: 700, fontFamily: 'inherit' },
  tabActive: { background: cv.surface, color: cv.text },
  friendList: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 },
  friendRow: { display: 'flex', alignItems: 'center', gap: 10, padding: '9px 10px', borderRadius: 11, border: '1px solid transparent', cursor: 'pointer', fontFamily: 'inherit', minWidth: 0 },
  friendAvatar: { width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 800, flexShrink: 0 },
  friendName: { flex: 1, minWidth: 0, fontSize: 13, color: cv.text, textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  check: { width: 18, height: 18, borderRadius: '50%', border: '1px solid transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, color: '#fff', flexShrink: 0 },
  emptyFriends: { gridColumn: '1 / -1', padding: '14px 12px', borderRadius: 11, border: `1px dashed ${cv.border}`, color: cv.textDim, fontSize: 12, lineHeight: 1.5, textAlign: 'center' },
  linkNotice: { background: cv.elevated, border: `1px solid ${cv.border}`, borderRadius: 10, padding: '12px 13px', color: cv.textMid, fontSize: 12, lineHeight: 1.5 },
  btnCancel: { padding: '9px 18px', borderRadius: 10, border: `1px solid ${cv.border}`, background: 'transparent', color: cv.textMid, cursor: 'pointer', fontSize: 13, fontFamily: 'inherit' },
  btnCreate: { padding: '9px 22px', borderRadius: 10, border: 'none', color: '#fff', fontSize: 13, fontFamily: 'inherit', fontWeight: 700 },
}
